import React from "react";

const Title = ({ title, color }: { title: string; color?: string }) => {
  return (
    <div className="section-title">
      <h4 style={{ color: `${color ? color : "black"}` }}>{title}</h4>
      <div />
    </div>
  );
};

export default Title;

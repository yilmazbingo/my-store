import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import Link from "next/link";
import { Carousel, Image } from "react-bootstrap";
import Loader from "@/components/Loader";
import Message from "@/components/Message";
import { carouselProductsRequestStart } from "@/redux/products-carousel/action.creators";
import { RootState } from "@/redux/rootReducer";

function ProductCarousel() {
  const dispatch = useDispatch();

  const carouselProductsState = useSelector(
    (state: RootState) => state.carouselProducts
  );
  const { error, loading, products } = carouselProductsState;

  useEffect(() => {
    dispatch(carouselProductsRequestStart());
  }, [dispatch]);

  return loading ? (
    <Loader />
  ) : error ? (
    <Message variant="danger">{error}</Message>
  ) : (
    <Carousel pause="hover" className="carousel">
      {products.map((product) => (
        <Carousel.Item key={product.id}>
          <Link href={`/product/${product.id}`}>
            <>
              <Image src={product.image} alt={product.name} fluid />
              <Carousel.Caption className="carousel.caption">
                <h4>
                  {product.name} ( ${product.price})
                </h4>
              </Carousel.Caption>
            </>
          </Link>
        </Carousel.Item>
      ))}
    </Carousel>
  );
}

export default ProductCarousel;
